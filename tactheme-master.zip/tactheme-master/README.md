# tactheme
Change your LINE theme using Termux software

# Installation
    pkg update
    pkg install git
    pkg install python
    git clone https://github.om/Noxturnix/tactheme

# Usage

Go to the folder you clone. Enter `./tactheme` to see how to use the sctipt. Make sure you downloaded the theme named "Cony" before using the script and apply it when you finished install your theme by using the script

    $ ./tactheme
    Usage: ./tactheme (arg1) [arg2]

    (arg1) is required
    [arg2] is optional (for advance user)

    Argrument 1:
            (Theme URL)
            reset

    Argrument 2:
            (Package name)  This option is for LINE Mod user (Default = jp.naver.line.android)
    $

# Example
    ./tactheme https://store.line.me/themeshop/product/793460b3-7514-42e1-8a04-4bb23c57c077

# Author
[Noxturnix](https://github.com/Noxturnix) from Noxtian team
